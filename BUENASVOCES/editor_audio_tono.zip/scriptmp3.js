import WaveSurfer from 'https://unpkg.com/wavesurfer.js@7/dist/wavesurfer.esm.js';
import RegionsPlugin from 'https://unpkg.com/wavesurfer.js@7/dist/plugins/regions.esm.js';

let wavesurfer;
let regionActiva;

document.addEventListener('DOMContentLoaded', () => {
  const archivoMP3 = document.getElementById('archivoMP3');
  const sliderTono = document.getElementById('sliderTono');
  const valorTono = document.getElementById('valorTono');

  archivoMP3.addEventListener('change', (e) => {
    const archivo = e.target.files[0];
    if (archivo) {
      if (wavesurfer) wavesurfer.destroy();
      wavesurfer = WaveSurfer.create({
        container: '#waveform',
        waveColor: '#46a5f9',
        progressColor: '#0d6efd',
        plugins: [RegionsPlugin.create()]
      });
      wavesurfer.loadBlob(archivo);
    }
  });

  sliderTono.addEventListener('input', () => {
    valorTono.textContent = sliderTono.value;
  });

  document.getElementById('btnPlay').addEventListener('click', () => wavesurfer && wavesurfer.playPause());
  document.getElementById('btnStop').addEventListener('click', () => wavesurfer && wavesurfer.stop());

  document.getElementById('btnRecortar').addEventListener('click', () => {
    const region = wavesurfer.regions.list[Object.keys(wavesurfer.regions.list)[0]];
    if (region) {
      regionActiva = region;
      alert(`Fragmento seleccionado desde ${region.start.toFixed(2)} a ${region.end.toFixed(2)} segundos.`);
    }
  });

  document.getElementById('btnDescargar').addEventListener('click', () => {
    alert('⚠️ Exportación de fragmentos no implementada en esta demo.');
  });

  document.getElementById('btnDescargarTodo').addEventListener('click', () => {
    alert('⚠️ Exportación total no implementada en esta demo.');
  });
});